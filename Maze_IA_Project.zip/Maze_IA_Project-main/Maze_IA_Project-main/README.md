# Maze_IA_Project 
 représenter un problème comme un graphe d’états en donnant une convenable représentation et mettre en application les algorithmes des stratégies de recherche
